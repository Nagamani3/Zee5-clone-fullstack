const AuthSchema = require("../models/auth");

/* @ HTTP REQUEST POST
@ACCESS PUBLIC
URL:api/auth/signup*/

exports.SignUp = async (req, res) => {
  //write signup logic here
  let { username, email, role, password } = req.body;
  try {
    let payload = {
      username,
      email,
      role,
      password,
    };
    let data = await AuthSchema.create(payload);
    res.status(201).json({ message: "Successfully user created", data });
  } catch (error) {
    console.log(error);
    res.status(501).json("server error");
  }
};

/* @ HTTP REQUEST POST
@ACCESS PUBLIC
URL:api/auth/sigin*/

exports.SignIn = (req, res) => {
  //write signin logic here
  res.send("ok its working signin ");
};
