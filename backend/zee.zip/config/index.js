require('dotenv').config()

module.exports = {
  PORT: process.env.PORT,
    MONGODB_URL_LOCAL: process.env.MONGODB_URL_LOCAL,
  NODE_ENV:process.env.NODE_ENV,
  MONGODB_URL_CLOUD: process.env.MONGODB_URL_CLOUD,
};